import urllib
import urllib2
import time
import sys

sys.argv[0]

month = int(sys.argv[1])
monthAmount = int(sys.argv[2])
currencyType = sys.argv[3]



#month = 1512086400

monthdays = [month]

x = 0
for i in range(monthAmount):
    monthdays.append(monthdays[x] + 86400)
    x = x + 1


i = currencyType

for timed in monthdays:
    time.sleep(1)
    print('https://min-api.cryptocompare.com/data/dayAvg?'
                        + 'fsym=' + i + '&tsym=USD&toTs=' + str(timed))
    CoinPriceDay = urllib.urlopen('https://min-api.cryptocompare.com/data/dayAvg?'
                        + 'fsym=' + i + '&tsym=USD&toTs=' + str(timed))
    x = CoinPriceDay.read().read().split('"USD":')[1].split(',"')[1]
    filed = open("Coins data\\" + i + '.txt', "a")
    filed.write(x)
    filed.close()


nextPoint = monthdays[x] + 86400
CoinPriceDay = urllib.urlopen('https://min-api.cryptocompare.com/data/dayAvg?'
                        + 'fsym=' + i + '&tsym=USD&toTs=' + str(nextPoint))
x = CoinPriceDay.read().split('"USD":')[1].split(',"')[1]
filed = open("Coins data\\" + i + 'Final.txt', "a")
filed.write(x)
filed.close()
