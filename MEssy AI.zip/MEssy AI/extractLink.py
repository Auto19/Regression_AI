import urllib
import urllib2
import time
import sys

## find the links to the charts of each coin

#time = ''


source = urllib.urlopen('https://coinmarketcap.com/all/views/all/').read()
table = source.split('<tbody>')
elements = table[1].split('<tr')
x = 0

coins = []
for i in elements:
    if(x!=0):
        links = i.split('class="text-left col-symbol"')
        coinlink = links[1].split('<')
        coinSym = coinlink[0].split('>')
        #print('https://coinmarketcap.com' + coinlink[0]) ## these are all the links to the coins pages
        coins.append(coinSym[1])
        #print(coins)
    x = x + 1

coinsAmount = x - 1

print(coins)



## create a 2D array storing the cordinates of each coin

# 1 hour = 3600, 1 day = 86400 ##November below
month = 1512086400
monthdays = [1512086400]

x = 0
for i in range(30):
    monthdays.append(monthdays[x] + 86400)
    x = x + 1

#coined = ['BTC', 'ETH']

for i in coins:
    for timed in monthdays:
        time.sleep(1)
        print('https://min-api.cryptocompare.com/data/dayAvg?'
                        + 'fsym=' + i + '&tsym=USD&toTs=' + str(timed))
        CoinPriceDay = urllib.urlopen('https://min-api.cryptocompare.com/data/dayAvg?'
                        + 'fsym=' + i + '&tsym=USD&toTs=' + str(timed))
        x = CoinPriceDay.read()
        filed = open("Coins data\\" + i + '.txt', "a")
        filed.write(x)
        filed.close()
