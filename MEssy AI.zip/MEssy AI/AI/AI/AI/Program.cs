﻿using System;
using System.Collections.Generic;
using System.Linq;

//TODO
/*
 * Write the public Algorithm functions :: done
 * Implement Main method :: done
 * Build AI processing in the sense of make it loop till Test gets below for instance .01 :: breaks on 
 *     maybe have it return a formula it uses
 *     use a range of best to worst choicing random inbetween
 * Build a processor to get data out of txt files 
 */

namespace AI
{
    class TaskManager
    {
        private List<Algorithm> generation;
        private double percentKilled;
        private List<XYPoint> PriorPoints;
        private XYPoint GuessPoint;
        private XYPointsD BestfitLineAB;
        private int counter = 1;

        //set this boolean with if a test of a generation ever gets below .01

        public TaskManager(int amount, double percent)
        {
            percentKilled = percent;
            PriorPoints = getPriorPoints();
            GuessPoint = getGuessPoint();

            generation = new List<Algorithm>();

            for (int i = 0; i < amount; i++)
            {
                generation.Add(new Algorithm(PriorPoints));
            }

           
            
        }

        public List<XYPoint> getPriorPoints()
        {
            List<XYPoint> a = new List<XYPoint>();

            //int counter = 1;
            string line;

            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\CharlieFligg20\Desktop\Religion project\Coins Data\BTC.txt");
            while ((line = file.ReadLine()) != null)
            {
                a.Add(new XYPoint() { X = counter, Y = Double.Parse(line) });
                counter++;
            }

            file.Close();

            return a;
        }

        public XYPoint getGuessPoint()
        {
            string line;

            System.IO.StreamReader file = new System.IO.StreamReader(@"C:\Users\CharlieFligg20\Desktop\Religion project\Coins Data\BTCFinal.txt");
            line = file.ReadLine();
            file.Close();

            return new XYPoint() { X = counter, Y = Double.Parse(line) };
        }

        public double TestAlgorithm(double correct, double givenValue)
        {
            //find a way to figure out a percent correctness of a individual bot (do we want to test for multiple points after)
            //using same alg as https://www.calculatorsoup.com/calculators/algebra/percent-difference-calculator.php
            float a = Math.Abs((float)correct - (float)givenValue);
            //float b = (float)correct.Y + (float)givenValue.Y;
            //Console.WriteLine(a);
            return a;//return 100f * a / (b / 2);
        }

        public List<XYPointsD> killOffWeak() 
        {
            List<double> estimated = new List<double>(generation.Count);
            List<Algorithm> survivingAlgs = new List<Algorithm>((int)((double)generation.Count * (1 - percentKilled)));
            //y = (c(d + a)x + b(e) + f)g

            for (int i = 0; i < generation.Count; i++) 
            {
                Algorithm Alg = generation[i];
                double estimatedPoint = (Alg.c * ((Alg.d + Alg.a) * GuessPoint.X) + Alg.b * (Alg.e) + Alg.f) * Alg.g;
                double closeness = TestAlgorithm(GuessPoint.Y, estimatedPoint);
                /*
                 * if closeness < .01% call it a match and print a, b, c, d, e, f, g
                 */
                estimated.Add(closeness);
            }
            estimated.Sort();
            /* foreach (double elm in estimated)
                Console.Write(elm + ", ");
            Console.WriteLine(estimated.ToString()); */
            //Console.WriteLine(estimated.Count);
            double breaker = estimated[(int)(estimated.Count * percentKilled)]; //Program is breaking at this point, fix it
            //int j = 0;
            foreach(Algorithm Alg in generation)
            {
                double estimatedPoint = (Alg.c * ((Alg.d + Alg.a) * GuessPoint.X) + Alg.b * (Alg.e) + Alg.f) * Alg.g;
                double closeness = TestAlgorithm(GuessPoint.Y, estimatedPoint);
                //Console.WriteLine(closeness);
                if (closeness <= breaker && closeness >= -breaker)
                {
                    survivingAlgs.Add(Alg);
                    //j++;
                }
            }
            double minc = survivingAlgs[0].c;
            double maxc = survivingAlgs[0].c;
            double mind = survivingAlgs[0].d;
            double maxd = survivingAlgs[0].d;
            double mine = survivingAlgs[0].e;
            double maxe = survivingAlgs[0].e;
            double minf = survivingAlgs[0].f;
            double maxf = survivingAlgs[0].f;
            double ming = survivingAlgs[0].g;
            double maxg = survivingAlgs[0].g;
            for (int i = 0; i < survivingAlgs.Count; i++)
            {
                if (survivingAlgs[i].c > maxc)
                    maxc = survivingAlgs[i].c;
                if (survivingAlgs[i].c < minc)
                    minc = survivingAlgs[i].c;
                if (survivingAlgs[i].d > maxd)
                    maxd = survivingAlgs[i].d;
                if (survivingAlgs[i].d < mind)
                    mind = survivingAlgs[i].d;
                if (survivingAlgs[i].e > maxe)
                    maxe = survivingAlgs[i].e;
                if (survivingAlgs[i].e < mine)
                    mine = survivingAlgs[i].e;
                if (survivingAlgs[i].f > maxf)
                    maxf = survivingAlgs[i].f;
                if (survivingAlgs[i].f < minf)
                    minf = survivingAlgs[i].f;
                if (survivingAlgs[i].g > maxg)
                    maxg = survivingAlgs[i].g;
                if (survivingAlgs[i].g < ming)
                    ming = survivingAlgs[i].g;
            }

            List<XYPointsD> survivors = new List<XYPointsD>() {
                new XYPointsD() { X=minc, Y=maxc },
                new XYPointsD() { X=mind, Y=maxd },
                new XYPointsD() { X=mine, Y=maxe },
                new XYPointsD() { X=minf, Y=maxf },
                new XYPointsD() { X=ming, Y=maxg },
            };
            BestfitLineAB = new XYPointsD() { X = survivingAlgs[0].a, Y = survivingAlgs[0].b };
            return survivors;
        }

        public void generateGeneration(int amountMachines, List<XYPointsD> survivors)
        {
            for(int i = 0; i < generation.Count; i++)
            {
                generation[i] = new Algorithm(survivors, BestfitLineAB);
            }
        }
        
        static void Main(string[] args)
        {
            //Change this to a function

            //Fields
            int MachinesPerGneration = 100;
            double MachinesAmountKilledOff = 0.2;

            //we want to loop through and test 2 points after the initial given points
            TaskManager manager = new TaskManager(MachinesPerGneration, MachinesAmountKilledOff);
            Console.WriteLine("generate manager successful");
            List<XYPointsD> survivors = manager.killOffWeak(); //return survivors (this should call, testGeneration)
            Console.WriteLine("producing generations");
            Console.WriteLine("Each Generation's Closeness to point");
            while (true) 
            {
                //key = Console.ReadKey(true).Key;
                manager.generateGeneration(MachinesPerGneration, survivors);
                survivors = manager.killOffWeak();
                double a = manager.BestfitLineAB.X;
                double b = manager.BestfitLineAB.Y;
                double c = survivors[0].Y;
                double d = survivors[1].Y;
                double e = survivors[2].Y;
                double f = survivors[3].Y;
                double g = survivors[4].Y;
                double estimatedPoint = (c * ((d + a) * manager.GuessPoint.X) + b * (e) + f) * g;
                Console.Write(manager.TestAlgorithm(manager.GuessPoint.Y, estimatedPoint));
                if(estimatedPoint <= (manager.GuessPoint.Y + 0.5) && estimatedPoint >= manager.GuessPoint.Y - 0.5)
                {
                    Console.WriteLine();
                    Console.WriteLine("Successful Generation generated");
                    Console.WriteLine("a: " + a);
                    Console.WriteLine("b: " + b);
                    Console.WriteLine("c: " + c);
                    Console.WriteLine("d: " + d);
                    Console.WriteLine("e: " + e);
                    Console.WriteLine("f: " + f);
                    Console.WriteLine("g: " + g);
                    Console.WriteLine("y = (c(d + a)x + b(e) + f)g");
                    Console.WriteLine("Solving for y; y = " + estimatedPoint);
                    Console.WriteLine("Solving for y of x + 1; y = " + (c * ((d + a) * (manager.GuessPoint.X+1)) + b * (e) + f) * g);
                    break;
                } else
                {
                    Console.Write(", ");
                }
                //Console.WriteLine(a);
            }

            //Wait for key press to close
            Console.ReadKey();
        }
        
    }

    class Algorithm
    {
        //Fields
        public double a, b, c, d, e, f, g;

        //trend line * variables
        //use margin of errors (this is probably where the AI comes in, need to find a constant/formula for this)
        //can use a spread as well /\
        /* Variables are (a, b, c, d, e, f, g)
         * The trend line -> y = (c(d + a)x + b(e) + f)g
         */
        public Algorithm(List<XYPointsD> cdef, XYPointsD BestFitLine)
        {

            Random rnd = new Random();

            //use the previous survivors and write an algorithm that curves to at.
            //XYPoints cdef in form of (Min, Max)
            a = BestFitLine.X; //Assumed a is X var, and b is Y var
            b = BestFitLine.Y;

            //Y is min, X is max ::: assumed in order c,d,e,f
            c = rnd.NextDouble() * (cdef[0].X - cdef[0].Y) + cdef[0].Y;
            d = rnd.NextDouble() * (cdef[1].X - cdef[1].Y) + cdef[1].Y;
            e = rnd.NextDouble() * (cdef[2].X - cdef[2].Y) + cdef[2].Y;
            f = rnd.NextDouble() * (cdef[3].X - cdef[3].Y) + cdef[3].Y;
            g = rnd.NextDouble() * (cdef[4].X - cdef[4].Y) + cdef[4].Y;

        }
        // If no prior
        public Algorithm(List<XYPoint> points)
        {
            double Max = 100; double Min = -100;

            //Random.NextDouble * (Max - Min) + Min; // gets a random numbers from max to min
            List<XYPoint> lineOfBestFit = GenerateLinearBestFit(points, out a, out b);
            b = -b;
            Random rnd = new Random();

            //Randomise
            c = rnd.NextDouble() * (Max - Min) + Min;
            d = rnd.NextDouble() * (Max - Min) + Min;
            e = rnd.NextDouble() * (Max - Min) + Min;
            f = rnd.NextDouble() * (Max - Min) + Min;
            g = rnd.NextDouble() * (Max - Min) + Min;

            // no previous survivors use random gneration
        }

        //to lazy to write this, got source code from
        //https://stackoverflow.com/questions/12946341/algorithm-for-scatter-plot-best-fit-line
        public List<XYPoint> GenerateLinearBestFit(List<XYPoint> points, out double a, out double b)
        {
            int numPoints = points.Count;
            double meanX = points.Average(point => point.X);
            double meanY = points.Average(point => point.Y);

            double sumXSquared = points.Sum(point => point.X * point.X);
            double sumXY = points.Sum(point => point.X * point.Y);

            a = (sumXY / numPoints - meanX * meanY) / (sumXSquared / numPoints - meanX * meanX);
            b = (a * meanX - meanY);

            double a1 = a;
            double b1 = b;

            return points.Select(point => new XYPoint() { X = point.X, Y = a1 * point.X - b1 }).ToList();
        }
    }

    public class XYPoint
    {
        public int X;
        public double Y;
    }

    public class XYPointsD
    {
        public double X;
        public double Y;
    }

    //Example Code for generating a best fit line
    /*
     * List<XYPoint> points = new List<XYPoint>()
                                   {
                                       new XYPoint() {X = 1, Y = 12},
                                       new XYPoint() {X = 2, Y = 16},
                                       new XYPoint() {X = 3, Y = 34},
                                       new XYPoint() {X = 4, Y = 45},
                                       new XYPoint() {X = 5, Y = 47}
                                   };

            Algorithm p = new Algorithm(points);
            double a, b;

            List<XYPoint> bestFit = p.GenerateLinearBestFit(points, out a, out b);
            Console.WriteLine("y = " + a.ToString() + "x " + (-b).ToString());
    */
}
